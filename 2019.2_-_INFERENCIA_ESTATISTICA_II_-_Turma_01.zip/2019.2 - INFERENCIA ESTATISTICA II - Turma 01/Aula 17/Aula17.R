############# Aula 16 #################

library(TeachingDemos) 
library(OneTwoSamples)

## uma variavel

################ normal, media com desvio padrao conhecido

# rnorm(n, mean, sd)
x <- rnorm(25, 100, 5)

## jeito 1

z.test(x, 100,stdev= 5)

# z.test(x, mu = 0, stdev, alternative = c("two.sided", "less", "greater"),
# sd = stdev, n=length(x), conf.level = 0.95, ...)

## jeito 2


# mean_test1(x, mu = 0, sigma = -1, side = 0)

mean_test1(x, mu = 100, sigma = 5, side = 0)


### exercicio


x<-c(33840, 32960, 41811, 35080, 35060,
32947, 32120, 32740, 33580, 33002)


z.test(x, 34720,stdev= 530)

mean_test1(x, mu = 34720, sigma = 530, side = 0)



################ normal, media com desvio padrao desconhecido

x <- rnorm(25, 100, 5)
mean(x)
sqrt(var(x))

## jeito 1

library(stats)

#t.test(x, y = NULL,
#       alternative = c("two.sided", "less", "greater"),
#       mu = 0, paired = FALSE, var.equal = FALSE,
#       conf.level = 0.95, ...)

t.test(x,mu=100, conf.level = 0.95)

## jeito 2

mean_test1(x, mu = 100, sigma = sqrt(var(x)), side = 0)

### exercicio

x<-c(33840, 32960, 41811, 35080, 35060,
32947, 32120, 32740, 33580, 33002)

t.test(x, mean=34720, conf.level=0.95)

mean_test1(x, mu = 34720, sigma = -1, side = 0)

################ proporcao


# rbinom(n, size, prob)
heads <- rbinom(1, size = 100, prob = .5)

pest<-heads/100
n<-100

## jeito 1

library(stats)

#prop.test(x, n, p = NULL,
#          alternative = c("two.sided", "less", "greater"),
#          conf.level = 0.95, correct = TRUE)

prop.test(heads,n,correct=FALSE, conf.level = 0.95)

heads

### exercicio


prop.test(120,200,p=0.5,correct=FALSE, conf.level = 0.95)

################ variancia, com media desconhecida

library(TeachingDemos)

# rnorm(n, mean, sd)
x <- rnorm(25, 100, 5)
mean(x)
var(x)
n=25

## jeito 1

sigma.test(x, sigmasq = 5)

#sigma.test(x, sigma = 1, sigmasq = sigma^2, alternative = c("two.sided", "less", "greater"), conf.level = 0.95, ...)

## jeito 2

var_test1(x, sigma2 = 5, mu = Inf, side = 0)

#var_test1(x, sigma2 = 1, mu = Inf, side = 0)

### exercicio

x<-c(3.43, 3.37, 3.58, 3.50, 3.68, 3.61,
3.42, 3.52, 3.66, 3.50, 3.36, 3.42)

sigma.test(x, sigmasq = 0.06, alternative="less")

var_test1(x, sigma2 = 0.06^2, mu = Inf, side = -1)


## duas variaveis

################ normal, diferen�a das medias com desvios padrao conhecidos e diferentes

library(OneTwoSamples)

# rnorm(n, mean, sd)
x <- rnorm(25, 200, 5)
nx= 25
sdx=5

y <- rnorm(20, 100, 6)
ny=20
sdy=6

## jeito 1

t.test(x,y)

## jeito 2

mean_test2(x,y)

### exercicio

x<-c(51, 57, 75, 35, 72, 84, 45, 11, 52, 57)
y<-c(27, 75, 49, 69, 73, 63, 79, 37, 84, 32)


t.test(x,y)
mean_test2(x,y)

################ normal, quociente de vari�ncias

# rnorm(n, mean, sd)
x <- rnorm(25, 200, 5)
nx= 25

y <- rnorm(20, 100, 5)
ny=20


## jeito 1

library(stats)

#var.test(x, y, ratio = 1,
#         alternative = c("two.sided", "less", "greater"),
#         conf.level = 0.95, ...)

var.test(x,y)

## jeito 2

library(OneTwoSamples)

#var_test2(x, y, mu = c(Inf, Inf), side = 0)

var_test2(x,y)


### exercicio


x<-c(-10, 16, -8, 9, 5, -5, 5, -11, 25, 25,
22, 16, -3, 40, 0, -5, 16, 30, 14, 22)

y<-c(-8, -3, 20, 22, 3 ,5 ,10, 14, -21, 8)

var.test(x,y)


var_test2(x,y)








