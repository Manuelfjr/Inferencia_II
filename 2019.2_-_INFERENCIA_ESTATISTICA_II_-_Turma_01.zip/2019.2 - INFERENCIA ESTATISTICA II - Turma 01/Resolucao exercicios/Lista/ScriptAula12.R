######## Aula 12 #############

## Exemplo 12.1

library(stats)

#binom.test(x, n, p = 0.5,
#           alternative = c("two.sided", "less", "greater"),
#           conf.level = 0.95)

binom.test(10,15, p = 0.9,  alternative ="less")
 
qbinom(0.05,15,0.9)

# Poder

seq <- c(0.9,0.8,0.7,0.6,0.5,0.4)
np <- length(seq)
x<-10
n<-15
pwr=matrix(0,nrow = np, ncol = 1)
P=matrix(seq,nrow = np, ncol = 1)

for (i in 1:np){
     p = P[i,1] 
     pwr[i,1] = pbinom(x,n,p)
  }

plot(P, pwr, type="l", lwd=2)


## Exemplo 12.2

X = c(98.73, 97.17, 100.17, 101.26, 94.47,
  96.39, 99.67, 97.77, 97.46, 97.41)

Y=X>97
Y

binom.test(8,10, p = 0.5,  alternative ="two.sided")

## TRVG

sumx=8
xbar=0.8
p0=0.5
n=10
lambda = -2*(sumx*p0 + n*(1-p0)-sumx*(1-p0)-sumx*xbar-n*(1-xbar)+sumx*(1-xbar) )

lambda
qchisq(0.95,1)

lambda >= qchisq(0.95,1)

# Poder

seq <- c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
np <- length(seq)
x<-8
n<-10
pwr=matrix(0,nrow = np, ncol = 1)
P=matrix(seq,nrow = np, ncol = 1)

for (i in 1:np){
     p = P[i,1] 
     pwr[i,1] = pbinom(x,n,p)
  }

plot(P, pwr, type="l", lwd=2)


  ## Exemplo 12.3


binom.test(143,250, p = 0.5,  alternative ="two.sided")

## TRVG

sumx=143
xbar=0.572
p0=0.5
n=250
lambda = -2*(sumx*p0 + n*(1-p0)-sumx*(1-p0)-sumx*xbar-n*(1-xbar)+sumx*(1-xbar) )

lambda
qchisq(0.95,1)

lambda >= qchisq(0.95,1)

# Poder

seq <- c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
np <- length(seq)
x<-143
n<-250
pwr=matrix(0,nrow = np, ncol = 1)
P=matrix(seq,nrow = np, ncol = 1)

for (i in 1:np){
     p = P[i,1] 
     pwr[i,1] = pbinom(x,n,p)
  }

plot(P, pwr, type="l", lwd=2)


## Exemplo 12.4

#lambda = 5

x=rpois(15, 5)
sumx=sum(x)
n=15
lambda0=5
xbar=mean(x)

# TRVG

lambda=-2*(-n*(lambda0-xbar) + sumx*log(lambda0/xbar))

qchisq(0.95,1)

lambda >= qchisq(0.95,1)


## Exemplo 12.5

sumx=2824
n=365
lambda0=4
xbar=sumx/n

# TRVG

lambda=-2*(-n*(lambda0-xbar) + sumx*log(lambda0/xbar))

qchisq(0.90,1)

lambda >= qchisq(0.90,1)


## Exemplo 12.6

sumx=125
n=25
lambda0=4
xbar=5

# TRVG

lambda=-2*(-n*(lambda0-xbar) + sumx*log(lambda0/xbar))

pvalor=1-pchisq(lambda,1)

lambda <= qchisq(0.05,1)
lambda <= qchisq(0.1,1)
lambda <= qchisq(0.01,1)
pvalor


# Poder

seq <- c(1,2,3,4,5,6)
nl <- length(seq)
x<-125
n<-25
xbar=x/n
pwr=matrix(0,nrow = nl, ncol = 1)
lambda1=matrix(seq,nrow = nl, ncol = 1)

for (i in 1:nl){

lambda=-2*(-n*(lambda1[i,1]-xbar) + sumx*log(lambda1[i,1]/xbar))
 
     pwr[i,1] = pchisq(lambda,1)
  }

plot(lambda1, pwr, type="l", lwd=2)



  






